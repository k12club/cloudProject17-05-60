      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
            Cloud STORE Version 1.0 by <a href="www.facebook.com/herosib">Database Anuson</a>
        </div>
        <!-- Default to the left -->
        Copyright &copy; 2017 <a href="www.facebook.com/herosib">Company</a>.All rights reserved.
      </footer>
    </div><!-- ./wrapper -->
        </div>
    </body>
</html>